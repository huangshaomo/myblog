<?php 
include "../config.inc.php";
// sleep(5);//停留5秒
// $_FILES:获取上传文件的信息
// array
//   'file' => 
//     array
//       'name' => string 'ab.cd.efg.png' (length=13)  上传文件的文件名
//       'type' => string 'image/png' (length=9)  文件类型
//       'tmp_name' => string 'C:\wamp\tmp\php2CC1.tmp' (length=23)  上传文件所放置的位置 及临时的文件名
//       'error' => int 0   错误号
//       'size' => int 30341  文件大小
// bool move_uploaded_file ( string $filename , string $destination )
// 返回的值：true or false
// true表示上传成功
// false：上传失败
// move_uploaded_file(上传临时文件名及路径,移动到新的文件位置及文件名)
// 任务：将上传的文件名改为：yyyymmddhhiiss+随机数+扩展名
$ext = explode(".",$_FILES['file']['name']);
// $c = count($ext);//获取数组中元素的个数
var_dump($ext);
$ext = end($ext);//获取数组中最后一个元素值
$filename = date("YmdHis").mt_rand().".{$ext}";
// var_dump($ext[$c - 1]);

$bool = move_uploaded_file($_FILES['file']['tmp_name'], LOCAL_UPLOAD.$filename);
$info['img_path'] = UPLOAD.$filename;//图片绝对路径
$info["local_img_path"] = LOCAL_UPLOAD.$filename;
if ($bool) {
	echo json_encode($info); 
}else{
	echo "fail";
}

