<?php 
include "../config.inc.php";
//连接数据库
$mysqli = @new mysqli(DB_HOST,DB_USER,DB_PWD,DB_NAME);
//用函数判断是否连接成功，$mysqli->connect_error登录成功为null，失败返回连接错误信息。
if($mysqli->connect_error){
    die("连接失败".$mysqli->connect_error);
}   
$mysqli->set_charset(DB_CHARSET);
$sql = "SELECT * FROM  `article` ";
$result = $mysqli->query($sql) or die("命令有误");
// $num_rows = $result ->num_rows;
$rows =array();
$sum = mysqli_num_rows($result);
while ($row = $result->fetch_assoc()) {
    $rows[] = $row;
}
// echo "<pre>";
echo json_encode($rows,JSON_UNESCAPED_UNICODE);
// echo "</pre>";
// var_dump(json_encode($rows,JSON_UNESCAPED_UNICODE));
// $person = json_encode($rows,JSON_UNESCAPED_UNICODE);
// var_dump($person);
// // echo $person[1]."id";
 ?>