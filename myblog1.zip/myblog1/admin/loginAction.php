<?php 
//链入配置文件
include("../config.inc.php");
//设置文字编码方式
header("content-type:text/html;charset=utf-8");
$userid = $_POST['userid'];//获取输入的用户名
$userpass= md5($_POST['userpass']);//获取输入的密码
//连接数据库
$mysqli = @new mysqli(DB_HOST,DB_USER,DB_PWD,DB_NAME);
//用函数判断是否连接成功，$mysqli->connect_error登录成功为null，失败返回连接错误信息。
if ($mysqli->connect_error) {
	die("连接失败".$mysqli->connect_error);
}
//定义数据库编码方式
$mysqli->set_charset(DB_CHARSET);
//执行数据库sql查询语句
$sql="select * from user where userid='{$userid}' ";

$result = $mysqli->query($sql) or die("命令有误");
//提取查询出的数据中的一条记录，保存在$row
$row = $result->fetch_assoc();
//如果$row存在记录，返回true
die(var_dump($row));
if ($row) {
	//获取数据库的账号密码并与输入的账号密码匹配
	$DB_username=$row['userid'];
	$DB_userpass=$row['userpass'];
	if ($userid==$DB_username&&$userpass==$DB_userpass) {
		header("location:index.html");  
		exit(); 
	}else{
		if($userid!=$DB_username&&$userpass==$DB_userpass){
			header("location:login.php?error_id=1");
			exit();
		}
		if ($userid==$DB_username&&$userpass!=$DB_userpass) {
			header("location:login.php?error_id=2");
			exit();
		}
		if ($userid!=$DB_username&&$userpass!=$DB_userpass) {
			header("location:login.php?error_id=1");
			exit();
		}
	}



}else{
		header("location:login.php?error_id=1");
		exit();

}

	

