<?php 
//把数据库数据提出来放到后台界面
include "../config.inc.php";
$mysqli = @new mysqli(DB_HOST,DB_USER,DB_PWD,DB_NAME);
//用函数判断是否连接成功，$mysqli->connect_error登录成功为null，失败返回连接错误信息。
if ($mysqli->connect_error) {
	die("连接失败".$mysqli->connect_error);
}
//定义数据库编码方式
$mysqli->set_charset(DB_CHARSET);
//执行数据库sql查询语句
$sql="select * from user";
$result = $mysqli->query($sql) or die("命令有误");
$rows =array();
while ($row = $result->fetch_assoc()) {
	$row['create_date']=date("Y-m-d H:i:s",$row['create_date']);
	$rows[] = $row;
}
echo json_encode($rows);
?>