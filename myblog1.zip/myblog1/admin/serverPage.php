<?php 
include("../config.inc.php");
/**
 * Created by PhpStorm.
 * User: dt.thxopen.com
 * Date: 2014/12/7
 * Time: 11:13
 */
$mysqli = new mysqli(DB_HOST,DB_USER,DB_PWD,DB_NAME);//根据实际情况进行修改
if ($mysqli -> connect_errno) {
    die("连接错误!".$mysqli -> connect_error);
}
$mysqli -> set_charset(DB_CHARSET);
$tableName = "article";//表名   可以根据实际分页情况改成不同的表名
 
//获取Datatables发送的参数 必要
$draw = $_GET['draw'];//这个值作者会直接返回给前台
 
//排序
$order_column = $_GET['order']['0']['column'];//那一列排序，从0开始
$order_dir = $_GET['order']['0']['dir'];//ase desc 升序或者降序
 
// 获取表中所有的字段名
$sql = "show full columns from {$tableName}";

$result = $mysqli -> query($sql);
while ($row = $result -> fetch_assoc()) {
    $fields[] = $row['Field'];
}
// var_dump($fields);



//拼接排序sql
$orderSql = "";
if(isset($order_column)){
    $i = intval($order_column);
    $orderSql = '';
    if (is_numeric($i)) {
       $orderSql = " order by {$fields[$i]} ".$order_dir;
    }
    
    // switch($i){
    //     case 0;$orderSql = " order by first_name ".$order_dir;break;
    //     case 1;$orderSql = " order by last_name ".$order_dir;break;
    //     case 2;$orderSql = " order by position ".$order_dir;break;
    //     case 3;$orderSql = " order by office ".$order_dir;break;
    //     case 4;$orderSql = " order by start_date ".$order_dir;break;
    //     case 5;$orderSql = " order by salary ".$order_dir;break;
    //     default;$orderSql = '';
    // }
}
//搜索
$search = $_GET['search']['value'];//获取前台传过来的过滤条件
 
//分页
$start = $_GET['start'];//从多少开始
$length = $_GET['length'];//数据长度
$limitSql = '';
$limitFlag = isset($_GET['start']) && $length != -1 ;
if ($limitFlag ) {
    $limitSql = " LIMIT ".intval($start).", ".intval($length);
}
 
//定义查询数据总记录数sql
$sumSql = "SELECT count(id) as sum FROM {$tableName}";
//条件过滤后记录数 必要
$recordsFiltered = 0;
//表的总记录数 必要
$recordsTotal = 0;
$recordsTotalResult = $mysqli->query($sumSql);
while ($row = $recordsTotalResult->fetch_assoc()) {
    $recordsTotal =  $row['sum'];
}
//定义过滤条件查询过滤后的记录数sql
$fieldLink1 = "";
$fieldLink2 = "";
foreach ($fields as $key => $value) {
    $fieldLink1.= "`".$value ."`||";
    $fieldLink2.= "`".$value ."`,";

}
$fieldLink1=substr($fieldLink1, 0,-2);
$fieldLink2=substr($fieldLink2, 0,-1);
// var_dump($fieldLink);
// exit;
$sumSqlWhere =" where {$fieldLink1} LIKE '%".$search."%'";
if(strlen($search)>0){
    $recordsFilteredResult = $mysqli->query($sumSql.$sumSqlWhere);
    while ($row = $recordsFilteredResult->fetch_assoc()) {
        $recordsFiltered =  $row['sum'];
    }
}else{
    $recordsFiltered = $recordsTotal;
}
 
//query data 查询数据
$totalResultSql = "SELECT {$fieldLink2} FROM {$tableName}";
$infos = array();
if(strlen($search)>0){
    //如果有搜索条件，按条件过滤找出记录
    $dataResult = $mysqli->query($totalResultSql.$sumSqlWhere.$orderSql.$limitSql);
    while ($row = $dataResult->fetch_assoc()) {
        foreach ($fields as $key => $value) {
            $obj[$value]=$row[$value];
        }
        // $obj = array($row['first_name'], $row['last_name'], $row['position'], $row['office'], $row['start_date'], $row['salary']);
        array_push($infos,$obj);
    }
}else{
    //直接查询所有记录
    $dataResult = $mysqli->query($totalResultSql.$orderSql.$limitSql) or die($mysqli ->error);

    while ($row = $dataResult->fetch_assoc()) {
        foreach ($fields as $key => $value) {
            $obj[$value]=$row[$value];
        }

        // $obj = array($row['first_name'], $row['last_name'], $row['position'],$row['office'], $row['start_date'], $row['salary']);
        array_push($infos,$obj);
    }
}
 
// echo "<pre>"; 
// var_dump($infos);
// echo "</pre>"; 
/*
 * Output 包含的是必要的
 */
echo json_encode(array(
    "draw" => intval($draw),
    "recordsTotal" => intval($recordsTotal),
    "recordsFiltered" => intval($recordsFiltered),
    "data" => $infos
));
 
 
function fatal($msg)
{
    echo json_encode(array(
        "error" => $msg
    ));
    exit(0);
}

 ?>