<?php 
//链入配置文件
include("../config.inc.php");
//设置文字编码方式
header("content-type:text/html;charset=utf-8");
$mysqli = @new mysqli(DB_HOST,DB_USER,DB_PWD,DB_NAME);
//用函数判断是否连接成功，$mysqli->connect_error登录成功为null，失败返回连接错误信息。
if ($mysqli->connect_error) {
	die("连接失败".$mysqli->connect_error);
}
//定义数据库编码方式
$mysqli->set_charset(DB_CHARSET);
//执行数据库sql查询语句
$dt=time();
$sql="insert into news (newTitle,newsPub,newsDate,newsContent) values('efawg','admin',{$dt},'sagbgtrbwbtwrtbwbt')";
$result = $mysqli->query($sql) or die("命令有误");
//提取查询出的数据中的一条记录，保存在$row
if ($result) {
	echo "数据添加成功";
}else{
	echo "数据添加失败";
}