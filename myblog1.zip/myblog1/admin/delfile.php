<?php 
  $local_img_path = $_GET['local_img_path'];
  $bool = unlink($local_img_path);
  // echo $bool;
  if ($bool) {
  	echo "ok";
  }else{
  	echo "no";
  }