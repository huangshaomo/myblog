<script src="../js/page.js"></script>

<?php 

//把数据库数据提出来放到后台界面
include "../config.inc.php";
$mysqli = @new mysqli(DB_HOST,DB_USER,DB_PWD,DB_NAME);
//用函数判断是否连接成功，$mysqli->connect_error登录成功为null，失败返回连接错误信息。
if ($mysqli->connect_error) {
	die("连接失败".$mysqli->connect_error);
}
//定义数据库编码方式
$mysqli->set_charset(DB_CHARSET);
//定义起始页
 $nowPage = 1;
 if (!empty($_GET)) {
 	$nowPage = $_GET['nowPage'];
 	if($nowPage==0){
 		echo '<script>';
 		echo "window.location.href='./page.php';";
 		echo '</script>';
 	}
 }
 //页面条数
 $pageSize = 20;
 //当前页面总条数

//统计数据表数据条数
$sql = "select count(*) as sum from user1";
$result = $mysqli->query($sql) or die("命令有误");
$row = $result->fetch_assoc();
//将提取获取的数据条数存入到sum
$sum = $row['sum'];
// 统计行数,向上取整，不够整除的数据多立一行
$countPage = ceil($sum / $pageSize);


 $location = ($nowPage - 1) * $pageSize;
 $sql = "select * from user1 limit {$location},{$pageSize}";
//执行数据库sql查询语句
$result = $mysqli->query($sql) or die("命令有误");
$rows =array();
while ($row = $result->fetch_assoc()) {
	// $row['create_date']=date("Y-m-d H:i:s",$row['create_date']);
	$rows[] = $row;
}
    echo "显示第{$nowPage}页数据<br>";
	foreach ($rows as $key => $value) {
		echo "id:".$value['id']."&nbsp &nbsp &nbsp &nbsp &nbsp";
		echo "Host:".$value['host']."&nbsp &nbsp &nbsp &nbsp &nbsp";
		echo "User:".$value['username']."&nbsp &nbsp &nbsp &nbsp &nbsp";
		echo "Password:".$value['password']."&nbsp &nbsp &nbsp &nbsp &nbsp";
		echo "<br>";
		}
	$nextPage = $nowPage + 1;
	$prePage = $nowPage - 1;
	echo $nowPage.'/'.$countPage."&nbsp &nbsp &nbsp &nbsp &nbsp"."数据条数为".$sum ;
echo "<a href='page.php?nowPage=0'; return false;>首页</a>";
echo "<a href='page.php?nowPage={$prePage}'>上一页</a>";
echo "<a href='page.php?nowPage={$nextPage}'>下一页</a>";
echo "<a href='page.php?nowPage={$countPage}'>尾页</a>";
// // echo json_encode($rows);
// echo "显示第{$nowpage}页数据";



//判断页面，借由地址栏上的？id传值判断
//首先获取数据（）