<!-- 获取类别表cate中的数据 -->
<?php 
include "../config.inc.php";
$mysqli = @new mysqli(DB_HOST,DB_USER,DB_PWD,DB_NAME);
//用函数判断是否连接成功，$mysqli->connect_error登录成功为null，失败返回连接错误信息。
if ($mysqli->connect_error) {
	die("连接失败".$mysqli->connect_error);
}
//定义数据库编码方式
$mysqli->set_charset(DB_CHARSET);
//执行数据库sql查询语句
$sql="select * from cate";
$result = $mysqli->query($sql) or die("命令有误");
$rows =array();
while ($row = $result->fetch_assoc()) {
	$rows[] = $row;
}
echo json_encode($rows,JSON_UNESCAPED_UNICODE);//	对变量进行 JSON 编码,在php5.4之前，json不支持中文，会默认编码成Unicode格式，在php5.4之后才支持编译成中文，添加JSON_UNESCAPED_UNICODE即可

 ?>