<?php 
$id =$_GET['id'];
$sql ="delete from user where id in ({$id})";
include "../config.inc.php";
$mysqli = @new mysqli(DB_HOST,DB_USER,DB_PWD,DB_NAME);
//用函数判断是否连接成功，$mysqli->connect_error登录成功为null，失败返回连接错误信息。
if ($mysqli->connect_error) {
	die("连接失败".$mysqli->connect_error);
}
//定义数据库编码方式
$mysqli->set_charset(DB_CHARSET);
$result = $mysqli->query($sql);
if($result){
	echo "删除成功";
}else{
	echo "删除失败";
}