<?php 
$adminName = $_POST['adminName'];
$password = md5($_POST['password']);
$password2 = md5($_POST['password2']);
$adminRole = $_POST['adminRole'];
$dt = time();//获取当前时间戳
include "./config.inc.php";
$mysqli = @new mysqli(DB_HOST,DB_USER,DB_PWD,DB_NAME);
//用函数判断是否连接成功，$mysqli->connect_error登录成功为null，失败返回连接错误信息。
if ($mysqli->connect_error) {
	die("连接失败".$mysqli->connect_error);
}
//定义数据库编码方式
$mysqli->set_charset(DB_CHARSET);
//2、插入insert语句
$sql="insert into user(userid,userpass,create_date)values('{$adminName}','{$password}','{$adminRole}',$dt)";
// 3、执行插入语句
$result = $mysqli->query($sql);
// 4、成功后失失败跳转
if ($result) {
	echo "添加成功";
}else{
	echo "添加失败";
}
//关闭数据库连接
$mysqli->close();

?>